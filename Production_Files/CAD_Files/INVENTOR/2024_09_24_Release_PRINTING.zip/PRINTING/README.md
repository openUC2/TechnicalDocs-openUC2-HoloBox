# Printing files

All files ready for printing on Prusa

## Files not intended to print

- [Really Useful Box](NOT-PRINTED/Application_openUC2_CORE_00_Really_Useful_Box_4l_DinA4_body_54.stl)
- [Flashlight](NOT-PRINTED/Application_openUC2_CORE_00_Torch_XML-T6_85.stl)
- All base puzzle like [Base puzzle](NOT-PRINTED/Application_openUC2_CORE_10_Base_puzzle_v3_2.stl)
- Cubes like [Cube](NOT-PRINTED/Application_openUC2_CORE_10_Cube_1x1_IM_4.stl)
- [Microscope objective](NOT-PRINTED/Application_openUC2_CORE_00_Microscope_objective_10x_96.stl)
- [Sample slide doubleslit](ANOT-PRINTED/pplication_openUC2_CORE_00_Sample_Doubleslit_75.stl)
- [Microscope slide](NOT-PRINTED/Application_openUC2_CORE_00_Microscope_Slide_65.stl)
- Magnets, "neodymium" and "round"
- lenses "india"
- doublesided adhesive pieces
- Frontsurface mirrors
- [Metal adapter ring for RMS objective thread](NOT-PRINTED/Application_openUC2_CORE_30_Linear_Stage_NEMA11_baseholder_bayonetmount_objective_rms_metaladapter_tall_94.stl)
- [linear stage](NOT-PRINTED/Application_openUC2_CORE_00_CTM28H-0601-10-Linear-Stage_87.stl)
- [gel pad anti-slip](NOT-PRINTED/Application_openUC2_CORE_00_Gelpad_antislip_cellphone_50mmDiameter_29.stl)

Files that are for mechanical reference and make no sense to 3D-print have been moved to the NON-PRINTED folder.
